from django.urls import path
from .views import *
from . import views

app_name = 'searchservice'

urlpatterns = [
    path('', views.index, name = "index"),
]
