from django.apps import AppConfig


class SearchserviceConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'searchservice'
